
DinoRunner iOS (Playground)
--------------------------
This is a simple SpriteKit-based Dino Runner prepared as a Swift playground.
How to use:
- Download and unzip the package.
- Open `DinoRunner.playground` in Xcode or Swift Playgrounds on iPad/Mac.
- Run the playground to see the live view and play with touch/space to jump.
Notes:
- This is a template created by the assistant. You can edit the code in `Contents.swift` to add skins, sounds or export to a full iOS app project.
