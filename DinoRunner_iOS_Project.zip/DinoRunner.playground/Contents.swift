
import UIKit
import SpriteKit
import PlaygroundSupport

let sceneSize = CGSize(width: 900, height: 420)

// Procedural simple dino texture helper
func makeDinoTexture(size: CGSize, bodyColor: UIColor, stripeColor: UIColor, hatColor: UIColor?) -> SKTexture {
    let renderer = UIGraphicsImageRenderer(size: size)
    let img = renderer.image { ctx in
        let rect = CGRect(origin: .zero, size: size)
        let bodyRect = rect.insetBy(dx: size.width*0.08, dy: size.height*0.12)
        let path = UIBezierPath(roundedRect: bodyRect, cornerRadius: size.height*0.25)
        bodyColor.setFill(); path.fill()
        // eye
        let eyeRadius = size.width * 0.035
        let eyeCenter = CGPoint(x: bodyRect.midX + bodyRect.width*0.12, y: bodyRect.midY - bodyRect.height*0.12)
        let eye = UIBezierPath(ovalIn: CGRect(x: eyeCenter.x-eyeRadius, y: eyeCenter.y-eyeRadius, width: eyeRadius*2, height: eyeRadius*2))
        UIColor.white.setFill(); eye.fill()
        let pupil = UIBezierPath(ovalIn: CGRect(x: eyeCenter.x-eyeRadius*0.5, y: eyeCenter.y-eyeRadius*0.35, width: eyeRadius, height: eyeRadius))
        UIColor.black.setFill(); pupil.fill()
        // legs
        let legW = size.width*0.08, legH = size.height*0.12
        let leftLeg = UIBezierPath(roundedRect: CGRect(x: bodyRect.minX + bodyRect.width*0.15, y: bodyRect.maxY - legH*0.5, width: legW, height: legH), cornerRadius: legW*0.3)
        let rightLeg = UIBezierPath(roundedRect: CGRect(x: bodyRect.minX + bodyRect.width*0.42, y: bodyRect.maxY - legH*0.5, width: legW, height: legH), cornerRadius: legW*0.3)
        bodyColor.setFill(); leftLeg.fill(); rightLeg.fill()
        if let hat = hatColor {
            let hatRect = CGRect(x: bodyRect.minX + bodyRect.width*0.02, y: bodyRect.minY - bodyRect.height*0.36, width: bodyRect.width*0.35, height: bodyRect.height*0.28)
            let hatPath = UIBezierPath(roundedRect: hatRect, cornerRadius: hatRect.height*0.2)
            hat.setFill(); hatPath.fill()
            let hatStripe = UIBezierPath(rect: CGRect(x: hatRect.minX + hatRect.width*0.06, y: hatRect.midY - hatRect.height*0.12, width: hatRect.width*0.88, height: hatRect.height*0.16))
            UIColor.white.setFill(); hatStripe.fill()
        }
    }
    return SKTexture(image: img)
}

// GameScene (SpriteKit)
class GameScene: SKScene, SKPhysicsContactDelegate {
    enum Category: UInt32 { case player = 1, ground = 2, obstacle = 4 }
    var player: SKSpriteNode!
    var ground: SKNode!
    var scoreLabel: SKLabelNode!
    var speedMultiplier: CGFloat = 1.0
    var lastObstacleTime: TimeInterval = 0
    var isGameOver = false
    var score = 0 { didSet { scoreLabel.text = "Score: \(score)" } }
    var skins: [SKTexture] = []
    var currentSkinIndex = 0
    override func didMove(to view: SKView) {
        backgroundColor = UIColor(red: 0.95, green: 0.96, blue: 0.97, alpha: 1)
        physicsWorld.gravity = CGVector(dx: 0, dy: -18)
        physicsWorld.contactDelegate = self
        setupGround(); setupSkins(); setupPlayer(); setupScore(); startSpawning()
    }
    func setupGround() {
        ground = SKNode()
        ground.position = CGPoint(x: 0, y: 80)
        ground.physicsBody = SKPhysicsBody(edgeFrom: CGPoint(x: 0, y: 0), to: CGPoint(x: sceneSize.width*10, y: 0))
        ground.physicsBody?.categoryBitMask = Category.ground.rawValue
        ground.physicsBody?.isDynamic = false
        addChild(ground)
        let tile = SKSpriteNode(color: UIColor(white: 0.12, alpha: 0.9), size: CGSize(width: sceneSize.width*2, height: 10))
        tile.position = CGPoint(x: sceneSize.width/2, y: 75); tile.zPosition = 1; addChild(tile)
    }
    func setupSkins() {
        let s1 = makeDinoTexture(size: CGSize(width: 160, height: 100), bodyColor: .systemGreen, stripeColor: .white, hatColor: nil)
        let s2 = makeDinoTexture(size: CGSize(width: 160, height: 100), bodyColor: .systemBlue, stripeColor: .yellow, hatColor: .systemRed)
        let s3 = makeDinoTexture(size: CGSize(width: 160, height: 100), bodyColor: .systemPurple, stripeColor: .white, hatColor: .systemOrange)
        let s4 = makeDinoTexture(size: CGSize(width: 160, height: 100), bodyColor: .brown, stripeColor: .black, hatColor: .black)
        skins = [s1,s2,s3,s4]
    }
    func setupPlayer() {
        let tex = skins.first ?? SKTexture(image: UIImage())
        player = SKSpriteNode(texture: tex); player.size = CGSize(width: 120, height: 80)
        player.position = CGPoint(x: sceneSize.width*0.18, y: 140); player.zPosition = 10
        player.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: player.size.width*0.6, height: player.size.height*0.7))
        player.physicsBody?.allowsRotation = false
        player.physicsBody?.categoryBitMask = Category.player.rawValue
        player.physicsBody?.contactTestBitMask = Category.obstacle.rawValue | Category.ground.rawValue
        addChild(player)
    }
    func setupScore() {
        scoreLabel = SKLabelNode(fontNamed: "Menlo-Bold"); scoreLabel.fontSize = 22
        scoreLabel.horizontalAlignmentMode = .right; scoreLabel.position = CGPoint(x: sceneSize.width - 18, y: sceneSize.height - 40)
        scoreLabel.zPosition = 50; score = 0; addChild(scoreLabel)
    }
    func spawnCactus() {
        let w: CGFloat = CGFloat.random(in: 22...36); let h: CGFloat = CGFloat.random(in: 40...84)
        let cactus = SKSpriteNode(color: UIColor(red: 0.06, green: 0.6, blue: 0.2, alpha: 1.0), size: CGSize(width: w, height: h))
        cactus.name = "obstacle"; cactus.position = CGPoint(x: sceneSize.width + w, y: 80 + h/2); cactus.zPosition = 8
        cactus.physicsBody = SKPhysicsBody(rectangleOf: cactus.size); cactus.physicsBody?.isDynamic = false; cactus.physicsBody?.categoryBitMask = Category.obstacle.rawValue
        addChild(cactus)
        let move = SKAction.moveBy(x: -(sceneSize.width + w + 100) * speedMultiplier, y: 0, duration: TimeInterval(2.6 / Double(speedMultiplier)))
        cactus.run(SKAction.sequence([move, SKAction.removeFromParent()]))
    }
    func spawnBird() {
        let yPositions: [CGFloat] = [160, 200, 240]; let y = yPositions.randomElement()!
        let bird = SKSpriteNode(color: .systemGray, size: CGSize(width: 46, height: 34)); bird.position = CGPoint(x: sceneSize.width + 80, y: y)
        bird.zPosition = 8; bird.name = "obstacle"; bird.physicsBody = SKPhysicsBody(rectangleOf: bird.size); bird.physicsBody?.isDynamic = false; bird.physicsBody?.categoryBitMask = Category.obstacle.rawValue
        addChild(bird)
        let dist = sceneSize.width + 200; let dur = TimeInterval(2.0 / Double(speedMultiplier))
        bird.run(SKAction.sequence([SKAction.moveBy(x: -dist, y: 0, duration: dur), SKAction.removeFromParent()]))
    }
    func spawnObstacle() { if Int.random(in:0...2)==0 { spawnCactus() } else { spawnBird() } }
    func startSpawning() { lastObstacleTime = 0 }
    override func update(_ currentTime: TimeInterval) {
        if isGameOver { return }
        let interval = max(0.7, 1.6 - Double(speedMultiplier)*0.12)
        if currentTime - lastObstacleTime > interval { spawnObstacle(); lastObstacleTime = currentTime }
        score += Int(1 * speedMultiplier)
        if score % 200 == 0 { speedMultiplier += 0.08 }
    }
    func didBegin(_ contact: SKPhysicsContact) {
        if isGameOver { return }
        if contact.bodyA.categoryBitMask == Category.obstacle.rawValue || contact.bodyB.categoryBitMask == Category.obstacle.rawValue {
            gameOver()
        }
    }
    func gameOver() {
        isGameOver = true
        let label = SKLabelNode(text: "Game Over — Tap to Restart"); label.fontSize = 28; label.position = CGPoint(x: sceneSize.width/2, y: sceneSize.height/2); label.zPosition = 100
        addChild(label)
        // stop physics on obstacles
        for child in children where child.name == "obstacle" { child.removeAllActions() }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if isGameOver {
            // restart scene
            if let view = self.view, let scene = SKScene(fileNamed: "GameScene") { view.presentScene(scene) }
            else { self.removeAllChildren(); setupGround(); setupSkins(); setupPlayer(); setupScore(); isGameOver=false; score=0; speedMultiplier=1.0 }
            return
        }
        if let _ = touches.first, player.physicsBody?.velocity.dy == 0 {
            player.physicsBody?.applyImpulse(CGVector(dx: 0, dy: 520))
        }
    }
}

// Setup view
let skView = SKView(frame: CGRect(origin: .zero, size: sceneSize))
let scene = GameScene(size: sceneSize)
scene.scaleMode = .aspectFit
skView.presentScene(scene)
let container = UIView(frame: CGRect(origin: .zero, size: sceneSize))
container.addSubview(skView)
PlaygroundPage.current.liveView = container
